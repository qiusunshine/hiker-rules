package model

type QQ struct {
	Uid    uint64 `json:"uid"`
	Name   string `json:"name"`
	Openid string `json:"openid"`
}
