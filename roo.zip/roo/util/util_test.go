package util

import (
	"fmt"
	"testing"
)

func TestNoCommentFmt(t *testing.T) {
	fmt.Println("111111")
	fmt.Println(NoCommentFmt("```\n引用 @testu 发表的：\n123456676\n```\n哈哈哈"))
}